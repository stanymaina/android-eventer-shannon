package com.eventer.app.common;

/**
 * Created by Gulzar on 24-10-2016.
 */
public interface Bindable<T> {
    void bind(T t);
}
